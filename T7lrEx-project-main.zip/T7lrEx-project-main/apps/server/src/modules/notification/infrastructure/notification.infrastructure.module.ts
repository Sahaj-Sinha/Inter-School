import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationContentSubscriber } from './subscribers/notification.content.subscriber'

import { NotificationCommentSubscriber } from './subscribers/notification.comment.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [NotificationContentSubscriber, NotificationCommentSubscriber],
  exports: [],
})
export class NotificationInfrastructureModule {}
