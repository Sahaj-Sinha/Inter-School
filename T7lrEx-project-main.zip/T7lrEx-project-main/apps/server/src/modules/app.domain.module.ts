import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { ContentDomainModule } from './content/domain'

import { CommentDomainModule } from './comment/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    ContentDomainModule,

    CommentDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
