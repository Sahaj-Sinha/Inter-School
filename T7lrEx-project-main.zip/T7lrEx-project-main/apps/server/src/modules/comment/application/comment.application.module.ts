import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { CommentDomainModule } from '../domain'
import { CommentController } from './comment.controller'

import { ContentDomainModule } from '../../../modules/content/domain'

import { CommentByContentController } from './commentByContent.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { CommentByUserController } from './commentByUser.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    CommentDomainModule,

    ContentDomainModule,

    UserDomainModule,
  ],
  controllers: [
    CommentController,

    CommentByContentController,

    CommentByUserController,
  ],
  providers: [],
})
export class CommentApplicationModule {}
