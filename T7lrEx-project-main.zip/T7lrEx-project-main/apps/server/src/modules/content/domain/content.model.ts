import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Comment } from '../../../modules/comment/domain'

@Entity()
export class Content {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  title: string

  @Column({ nullable: true })
  description?: string

  @Column({ nullable: true })
  contentType?: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.contents)
  @JoinColumn({ name: 'userId' })
  user?: User

  @OneToMany(() => Comment, child => child.content)
  comments?: Comment[]

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
