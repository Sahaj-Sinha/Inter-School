import { User } from '../user'

import { Comment } from '../comment'

export class Content {
  id: string

  title: string

  description?: string

  contentType?: string

  userId: string

  user?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  comments?: Comment[]
}
