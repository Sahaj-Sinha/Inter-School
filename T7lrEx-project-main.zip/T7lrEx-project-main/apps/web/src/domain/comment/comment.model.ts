import { Content } from '../content'

import { User } from '../user'

export class Comment {
  id: string

  text: string

  contentId: string

  content?: Content

  userId: string

  user?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
