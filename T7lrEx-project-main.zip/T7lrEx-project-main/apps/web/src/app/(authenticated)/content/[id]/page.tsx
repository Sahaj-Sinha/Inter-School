'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Avatar, List, Input, Button } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ContentDetailPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()

  const [content, setContent] = useState(null)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const contentData = await Api.Content.findOne(params.id, {
          includes: ['user', 'comments.user'],
        })
        setContent(contentData)
        setComments(contentData.comments)
      } catch (error) {
        enqueueSnackbar('Failed to fetch content details', { variant: 'error' })
      }
    }

    fetchContent()
  }, [params.id])

  const handleAddComment = async () => {
    if (!commentText.trim()) {
      enqueueSnackbar('Comment text cannot be empty', { variant: 'error' })
      return
    }

    try {
      const newComment = await Api.Comment.createOneByContentId(params.id, {
        text: commentText,
        userId,
      })
      setComments([...comments, newComment])
      setCommentText('')
      enqueueSnackbar('Comment added successfully', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to add comment', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Content Details</Title>
      {content ? (
        <Card title={content.title}>
          <Paragraph>{content.description}</Paragraph>
          <Text type="secondary">
            Published by: {content.user?.name || 'Unknown'}
          </Text>
          <Text type="secondary">
            {' '}
            on {dayjs(content.dateCreated).format('MMMM D, YYYY')}
          </Text>
        </Card>
      ) : (
        <Text>Loading content details...</Text>
      )}
      <Title level={4}>Comments</Title>
      <List
        dataSource={comments}
        renderItem={item => (
          <List.Item
            key={item.id}
            actions={[dayjs(item.dateCreated).format('MMMM D, YYYY h:mm A')]}
          >
            <List.Item.Meta
              avatar={
                <Avatar
                  style={{ backgroundColor: '#87d068' }}
                  icon={<UserOutlined />}
                />
              }
              title={item.user?.name || 'Anonymous'}
              description={<p>{item.text}</p>}
            />
          </List.Item>
        )}
      />
      {authentication.isAuthenticated && (
        <div>
          <Input.TextArea
            rows={4}
            value={commentText}
            onChange={e => setCommentText(e.target.value)}
          />
          <Button
            type="primary"
            onClick={handleAddComment}
            style={{ marginTop: '10px' }}
          >
            Add Comment
          </Button>
        </div>
      )}
    </PageLayout>
  )
}
