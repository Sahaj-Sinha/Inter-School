'use client'

import { useEffect, useState } from 'react'
import { Button, Form, Input, List, Typography, Avatar } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { TextArea } = Input
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function CommentSectionPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [content, setContent] = useState(null)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const contentData = await Api.Content.findOne(params.id, {
          includes: ['user', 'comments.user'],
        })
        setContent(contentData)
        setComments(contentData.comments)
      } catch (error) {
        enqueueSnackbar('Failed to fetch content details.', {
          variant: 'error',
        })
      }
    }

    fetchContent()
  }, [params.id])

  const handleCommentSubmit = async () => {
    if (!commentText.trim()) {
      enqueueSnackbar('Comment text cannot be empty.', { variant: 'error' })
      return
    }

    try {
      const newComment = await Api.Comment.createOneByContentId(params.id, {
        text: commentText,
        userId: userId,
      })
      setComments([...comments, newComment])
      setCommentText('')
      enqueueSnackbar('Comment added successfully.', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to post comment.', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>{content?.title}</Title>
      <Text>{content?.description}</Text>
      <List
        dataSource={comments}
        header={`${comments.length} ${comments.length > 1 ? 'comments' : 'comment'}`}
        itemLayout="horizontal"
        renderItem={item => (
          <List.Item>
            <List.Item.Meta
              avatar={<Avatar icon={<UserOutlined />} />}
              title={item.user?.name}
              description={item.text}
            />
            <div>{dayjs(item.dateCreated).format('YYYY-MM-DD HH:mm')}</div>
          </List.Item>
        )}
      />
      {authentication.isAuthenticated && (
        <List.Item>
          <Avatar icon={<UserOutlined />} />
          <Form.Item>
            <TextArea
              rows={4}
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
            />
            <Button
              htmlType="submit"
              loading={false}
              onClick={handleCommentSubmit}
              type="primary"
            >
              Add Comment
            </Button>
          </Form.Item>
        </List.Item>
      )}
    </PageLayout>
  )
}
