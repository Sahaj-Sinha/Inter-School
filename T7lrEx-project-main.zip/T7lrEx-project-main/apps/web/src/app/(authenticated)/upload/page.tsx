'use client'

import { Button, Form, Input, Select, Upload } from 'antd'
import { UploadOutlined } from '@ant-design/icons'
import { useState } from 'react'
import { Typography } from 'antd'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UploadContentPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()
  const [fileList, setFileList] = useState([])

  const handleUpload = async options => {
    const { file } = options
    const url = await Api.Upload.upload(file)
    setFileList(fileList => [...fileList, { url: url, status: 'done' }])
  }

  const onFinish = async values => {
    try {
      await Api.Content.createOneByUserId(userId, {
        title: values.title,
        description: values.description,
        contentType: values.contentType,
        userId: userId,
      })
      enqueueSnackbar('Content uploaded successfully', { variant: 'success' })
      router.push('/contents')
    } catch (error) {
      enqueueSnackbar('Failed to upload content', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Upload Educational Content</Title>
      <Text type="secondary">
        Share your knowledge on economic empowerment by uploading articles or
        videos.
      </Text>
      <Form
        form={form}
        onFinish={onFinish}
        layout="vertical"
        style={{ marginTop: '20px' }}
      >
        <Form.Item
          name="title"
          label="Title"
          rules={[{ required: true, message: 'Please input the title!' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="description" label="Description">
          <Input.TextArea rows={4} />
        </Form.Item>
        <Form.Item
          name="contentType"
          label="Content Type"
          rules={[
            { required: true, message: 'Please select the content type!' },
          ]}
        >
          <Select placeholder="Select a content type">
            <Select.Option value="article">Article</Select.Option>
            <Select.Option value="video">Video</Select.Option>
          </Select>
        </Form.Item>
        <Form.Item label="Upload File">
          <Upload fileList={fileList} customRequest={handleUpload} maxCount={1}>
            <Button icon={<UploadOutlined />}>Click to Upload</Button>
          </Upload>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
