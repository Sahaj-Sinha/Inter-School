'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Row, Col, Avatar } from 'antd'
import { ReadOutlined, VideoCameraOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function EducationalContentListPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [contents, setContents] = useState<Model.Content[]>([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('You must be logged in to view this content', {
        variant: 'error',
      })
      router.push('/home')
      return
    }

    const fetchContents = async () => {
      try {
        const contentsFound = await Api.Content.findMany({
          includes: ['user', 'comments.user'],
        })
        setContents(contentsFound)
      } catch (error) {
        enqueueSnackbar('Failed to load contents', { variant: 'error' })
      }
    }

    fetchContents()
  }, [userId, router])

  const handleContentClick = (contentId: string) => {
    router.push(`/content/${contentId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Educational Contents</Title>
      <Paragraph>
        Explore a variety of educational articles and videos on economic
        empowerment.
      </Paragraph>
      <Row gutter={[16, 16]}>
        {contents?.map(content => (
          <Col key={content.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              onClick={() => handleContentClick(content.id)}
              cover={
                content.contentType === 'video' ? (
                  <VideoCameraOutlined
                    style={{ fontSize: '48px', color: '#1890ff' }}
                  />
                ) : (
                  <ReadOutlined
                    style={{ fontSize: '48px', color: '#1890ff' }}
                  />
                )
              }
            >
              <Card.Meta
                avatar={<Avatar src={content.user?.pictureUrl} />}
                title={content.title}
                description={
                  <>
                    <Text>{content.description}</Text>
                    <br />
                    <Text type="secondary">
                      {dayjs(content.dateCreated).format('DD MMM YYYY')}
                    </Text>
                  </>
                }
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
